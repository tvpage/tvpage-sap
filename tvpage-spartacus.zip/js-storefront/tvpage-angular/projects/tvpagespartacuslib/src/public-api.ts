/*
 * Public API Surface of tvpagespartacuslib
 */

export * from './lib';