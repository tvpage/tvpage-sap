export interface TvpageContentData {
    html?: string;
    metatags?: string;
}