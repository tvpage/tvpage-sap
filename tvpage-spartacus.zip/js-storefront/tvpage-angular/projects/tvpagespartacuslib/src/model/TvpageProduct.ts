import { Product } from '@spartacus/core';

export interface TvpageProduct extends Product {
  tvpageVideoJson?: string;
}