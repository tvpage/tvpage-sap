import { CmsComponent } from '@spartacus/core';

export interface TvpageVideoCmsComponent extends CmsComponent {
  srcUrl?: string;
}