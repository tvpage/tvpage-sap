export abstract class TvpageConfig {
  tvpage?: {
    accountId: string;
  };
}