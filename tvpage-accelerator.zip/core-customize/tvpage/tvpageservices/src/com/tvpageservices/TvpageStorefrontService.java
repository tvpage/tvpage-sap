package com.tvpageservices;

public interface TvpageStorefrontService {

    String getTvpageStorefrontHtml(String uri);

    String getTvpageStorefrontMetaTags(String uri);
}
