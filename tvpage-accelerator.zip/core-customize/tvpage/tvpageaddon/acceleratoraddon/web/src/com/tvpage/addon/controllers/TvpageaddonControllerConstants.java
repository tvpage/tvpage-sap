/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package com.tvpage.addon.controllers;

/**
 *
 */
public interface TvpageaddonControllerConstants {
    // implement here controller constants used by this extension
}
