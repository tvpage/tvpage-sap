package com.tvpage.occ.constants;

@SuppressWarnings({"deprecation", "squid:CallToDeprecatedMethod"})
public class TvpageoccConstants extends GeneratedTvpageoccConstants {
    public static final String EXTENSIONNAME = "tvpageocc";

    private TvpageoccConstants() {
        //empty
    }


}
